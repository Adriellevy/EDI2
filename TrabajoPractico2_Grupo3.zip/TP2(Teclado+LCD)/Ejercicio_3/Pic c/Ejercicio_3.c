#include <Ejercicio_3.h>
#fuses INTRC_IO, NOWDT, NOMCLR

#define LCD_ENABLE_PIN  PIN_B0 //Librerias para el LCD
#define LCD_RS_PIN      PIN_B1
#define LCD_RW_PIN      PIN_B2
#define LCD_DATA4       PIN_B4
#define LCD_DATA5       PIN_B5
#define LCD_DATA6       PIN_B6
#define LCD_DATA7       PIN_B7
#include <lcd.c>

void InitGPIO();

void main() {

   InitGPIO();
   int pos = 0;
   
   while(TRUE) 
   {      
      lcd_putc("\fRotando mensaje\n en LCD 16x2"); // Muestro fijo por 3 segundos
      delay_ms(3000);

      for(pos = 1; pos <= 17 - 4; pos++)  // Muevo EDI2 en la primera l�nea
      {                                   // 17 columnas - 4 letras
         lcd_putc("\f");                  // borro lo escrito  
         lcd_gotoxy(pos, 1);              // Muevo a la posicion que corresponda en la linea 1 (x,y)     
         printf(lcd_putc, "EDI2");        // Escribo EDI2 en dicha posicion
         delay_ms(300);
      }
    
      for(pos = 1; pos <= 17 - 4; pos++) // Muevo EDI2 con mismo procedimiento pero en la segunda l�nea
      {
         lcd_putc("\f");
         lcd_gotoxy(pos, 2);
         printf(lcd_putc, "EDI2");
         delay_ms(300);
      }        
   }
}


void InitGPIO(void){
    set_tris_a(0b00000000);   // A es ENTRADA
    set_tris_b(0b00000000);   // PORTB como SALIDA
    lcd_init(); 
}
