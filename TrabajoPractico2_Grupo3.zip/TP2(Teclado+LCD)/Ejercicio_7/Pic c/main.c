#include <16F1827.h>
#device ADC=10
#use delay(internal=4MHz)

#fuses NOWDT, INTRC_IO, NOMCLR

//======= VARIABLES GLOBALES =======
volatile int16 adc_value = 0;

//======= PROTOTIPOS =======
void INIT_ADC();
void INIT_INTERRUPTS();
void INIT_GPIO();
void INIT_DAC();
void INIT_TIMER_0();

//======= RUTINA DE INTERRUPCI�N =======
#INT_AD
void isr_adc(void){
   adc_value = read_adc(ADC_READ_ONLY); // Leo el resultado
   dac_write(adc_value*31/(1023));                // Lo mando al DAC
   read_adc(ADC_START_ONLY);
}

#INT_TIMER0 
void TIMER0_ISR()
{
   set_timer0(0);
   read_adc(ADC_START_ONLY); // Inicio nueva conversi�n
}

//======= INICIALIZACIONES =======
void INIT_ADC() {
   setup_adc_ports(sAN0);         // RA0 como anal�gico
   setup_adc(ADC_CLOCK_INTERNAL); // Reloj ADC interno
   set_adc_channel(0);            // Canal AN0
   read_adc(ADC_START_ONLY);
}

void INIT_DAC(void){
   setup_dac(DAC_VSS_VDD | DAC_OUTPUT); // Habilito DAC con salida f�sica
}

void INIT_INTERRUPTS() {
   enable_interrupts(INT_AD);     // Habilita interrupci�n del ADC
   enable_interrupts(INT_TIMER0); // Habilita interrupcion timer0
   enable_interrupts(GLOBAL);     // Interrupciones globales
}

void INIT_TIMER_0()
{
   setup_timer_0(RTCC_INTERNAL | RTCC_DIV_32); // M�s lento para que d� tiempo
   set_timer0(0);
}

void INIT_GPIO(void){
    set_tris_a(0b00000001);   // RA0 como entrada 
    set_tris_b(0x00);         // PORTB como salida
}

//======= PROGRAMA PRINCIPAL =======
void main() {
   INIT_GPIO();
   INIT_DAC();
   INIT_ADC();
//!   INIT_TIMER_0();
   INIT_INTERRUPTS();


   while(TRUE) {
      // Nada que hacer en el loop principal
   }
}

