#include <main.h>
#fuses NOWDT, INTRC_IO, NOMCLR

#define LCD_ENABLE_PIN PIN_B3 //Librerias para el LCD 
#define LCD_RS_PIN PIN_B1 
#define LCD_RW_PIN PIN_B2 
#define LCD_DATA4 PIN_B4 
#define LCD_DATA5 PIN_B5 
#define LCD_DATA6 PIN_B6 
#define LCD_DATA7 PIN_B7

#include <lcd.c>
//======= VARIABLES GLOBALES =======
volatile int1 adc_enable = 1;   // Habilitaci�n del ADC (1 = activo, 0 = pausado)

//======= PROTOTIPOS =======
void init_adc();
void init_interrupts();
void init_GPIO();

//======= RUTINA DE INTERRUPCI�N =======
#INT_IOC
void ext_isr(void) {
   // Cada flanco en RB0 alterna el estado de lectura ADC
   adc_enable = !adc_enable;
}

//======= INICIALIZACIONES =======
void init_adc() {
   setup_adc_ports(sAN0);         // RA0 como anal�gico
   setup_adc(ADC_CLOCK_INTERNAL); // Reloj ADC interno
   set_adc_channel(0);            // Canal 0 = RA0
   //delay_us(20);                  // Tiempo de adquisici�n PREGUNTAR
}

void init_interrupts() {
   enable_interrupts(INT_IOC_B0);    // Habilita interrupci�n externa en RB0
   enable_interrupts(GLOBAL);
}


void init_GPIO(void){
    set_tris_a(0xFF);   // A es ENTRADA
    set_tris_b(0b00000001);   // PORTB como SALIDA
    lcd_init(); 
}
//======= PROGRAMA PRINCIPAL =======
void main() {
   int16 adc_value;
   float voltage;
   
   init_GPIO();
   lcd_putc("\fADC PIC16F1827");  

   init_adc();
   init_interrupts();

   while(TRUE) {
      if(adc_enable) {
         adc_value = read_adc();        // Leer ADC (10 bits)
         voltage = (adc_value * 5.0) / 1023.0;   // Convertir a voltaje (0-5V)

         lcd_putc("\f");  
         printf(lcd_putc, "ADC: %4Lu", adc_value);
         lcd_gotoxy(1,2);
         printf(lcd_putc, "V= %1.2f V", voltage);

         delay_ms(200);
      }
      else {
         // Si est� pausado, mostrar mensaje
         lcd_putc("\fADC PAUSADO"); 
         //lcd_putc("\f");  
         //printf(lcd_putc, "ADC: %4Lu", adc_value);
         lcd_gotoxy(1,2);
         printf(lcd_putc, "V= %1.2f V", voltage);
         delay_ms(200);
      }
   }
}
