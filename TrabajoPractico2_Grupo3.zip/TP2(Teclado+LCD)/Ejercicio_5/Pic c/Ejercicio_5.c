#include <Ejercicio_5.h>
#use fast_io(B)
#fuses NOWDT, NOMCLR

//=======PROTOTIPOS=======
void INIT_GPIO();
void INIT_TIMER_0();
void INIT_INT_ICO();
void INIT_TIMER_1();

//======CHAR_TECLADO=====
char const teclado[4][3] = {
   {'1', '2', '3'},
   {'4', '5', '6'},
   {'7', '8', '9'},
   {'*', '0', '#'}
};

//======DEFINES_LCD======
#define LCD_ENABLE_PIN  PIN_A2 // Pines del LCD
#define LCD_RS_PIN      PIN_A0
#define LCD_RW_PIN      PIN_A1
#define LCD_DATA4       PIN_A3
#define LCD_DATA5       PIN_A4
#define LCD_DATA6       PIN_A6
#define LCD_DATA7       PIN_A7
#include <lcd.c>

//======PUERTOS TECLADO========
const int PuertosTecladoEntrada[] = { PIN_B0, PIN_B1, PIN_B2 };
const int PuertosTecladoSalida[]  = { PIN_B4, PIN_B5, PIN_B6, PIN_B7 };

int port=0; 

// ====== VARIABLES P/CONTRASE�A ======
char contrasenia[3] = {'2','5','3'};   // Contrase�a fija
char entrada[3];                       
int indice = 0;                       

// ====== CONTROL DE TIMER1 ======
volatile int contador = 0;

void main()
{
   INIT_GPIO();
   INIT_TIMER_0();
   INIT_INT_ICO();
   INIT_TIMER_1();

   lcd_init();                      
   lcd_putc("\fINGRESE CLAVE:");      // Mensaje inicial

   while(TRUE)
   {
   }
}

void INIT_GPIO(){
   set_tris_a(0x00);       
   set_tris_b(0b00000111); 
   output_b(0x00);
}

void INIT_TIMER_0() 
{
   setup_timer_0(RTCC_INTERNAL | RTCC_DIV_256);
   set_timer0(0); 
   enable_interrupts(INT_TIMER0);
   enable_interrupts(global);
}

#INT_TIMER0 
void TIMER0_ISR()
{
   set_timer0(0);
   port++;
   if(port>3)port=0;

   // Todos prendidos
   output_high(PuertosTecladoSalida[0]);
   output_high(PuertosTecladoSalida[1]);
   output_high(PuertosTecladoSalida[2]);
   output_high(PuertosTecladoSalida[3]);

   // Apagamos el que tiene el port
   output_toggle(PuertosTecladoSalida[port]);
}

void INIT_INT_ICO()
{
   enable_interrupts(INT_EXT_H2L);
   enable_interrupts(INT_IOC);
   enable_interrupts(GLOBAL);
}

// ====== CONFIG TIMER1 ======
void INIT_TIMER_1() {
   setup_timer_1(T1_INTERNAL | T1_DIV_BY_8); 
   disable_interrupts(INT_TIMER1); // apagado por defecto
}

#INT_TIMER1
void TIMER1_ISR(void) {
   contador++;
   if(contador>2){
      disable_interrupts(INT_TIMER1);   // solo cuando se habilita
      lcd_putc("\fINGRESE CLAVE:");
      contador=0;
   }
}

// ======== TECLADO MATRICIAL =========
#INT_IOC 
void EXT_isr(void) {
   char tecla = 0;

   if(!input_state(PuertosTecladoEntrada[0])) {
      tecla = teclado[port][0]; 
   }
   if(!input_state(PuertosTecladoEntrada[1])) {
      tecla = teclado[port][1]; 
   }
   if(!input_state(PuertosTecladoEntrada[2])) {
      tecla = teclado[port][2]; 
   }

   if(tecla != 0) 
   {
      entrada[indice] = tecla; 
      LCD_PUTC('\f');
      lcd_gotoxy(9, 1); 
      lcd_putc(tecla);

      if(entrada[indice] != contrasenia[indice]) 
      {
         lcd_putc("\fClave Incorrecta");
         indice = 0;  

         // arranca Timer1 ? 500ms
         set_timer1(65536 - 62500/2); // Fosc=4MHz, presc=8 ? 1 tick=8us ? 62500 ticks � 500ms
         clear_interrupt(INT_TIMER1);
         enable_interrupts(INT_TIMER1);
         return;
      }

      indice++; 
      
      if(indice == 3) 
      {
         lcd_putc("\fClave Correcta");
         indice = 0;   
         set_timer1(0); 
         clear_interrupt(INT_TIMER1);
         enable_interrupts(INT_TIMER1);
      }
   }
}

